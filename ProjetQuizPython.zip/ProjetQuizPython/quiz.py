## COTTEL Thibault
## QUIZ Python
## -> Interface graphique avec Tkinter
## -> Chargement de données avec un fichier externe CSV
## -> Persistance de données avec la sauvegarde des scores dans un fichier JSON


import os
import random
import csv
import json
import tkinter as tk
from tkinter import messagebox
from tkinter import simpledialog
from PIL import Image, ImageTk

# --- CONFIGURATION ---
FICHIER_QUESTIONS = "questions.csv"
DOSSIER_IMAGES = "images"
VIES_DEPART = 3
TAILLE_MAX_IMAGE = (700, 500)

# --- THÈME GRAPHIQUE ---
COULEUR_FOND = "#2a2d43"
COULEUR_TEXTE = "#f4f4f4"
COULEUR_BOUTON = "#4c5c91"
COULEUR_BOUTON_SURVOL = "#6279b8"
COULEUR_ENTRY_FOND = "#3e4a75"

# --- GESTION DU SCOREBOARD (NOUVELLE VERSION) ---
FICHIER_SCORES = "scoreboard.json"

def charger_scores():
    """Charge le dictionnaire des scores. S'il n'existe pas, retourne un dictionnaire vide."""
    try:
        with open(FICHIER_SCORES, 'r') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {} # On retourne un dictionnaire vide maintenant

def sauvegarder_scores(scores_par_theme):
    """Sauvegarde le dictionnaire complet des scores."""
    # Pas besoin de trier ici, on le fera au moment d'ajouter un score.
    with open(FICHIER_SCORES, 'w') as f:
        json.dump(scores_par_theme, f, indent=4)

# --- Quiz ---

class QuizApp:
    def __init__(self, master):
        self.master = master
        master.title("Track Quiz")
        master.geometry("800x650")
        master.configure(bg=COULEUR_FOND)

        self.current_frame = None 
        
        # 1. Créer le conteneur principal
        container = tk.Frame(master, bg=COULEUR_FOND)
        container.pack(side="top", fill="both", expand=True)
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        # 2. Créer le dictionnaire des frames AVANT de l'utiliser
        self.frames = {} 

        # 3. Remplir le dictionnaire avec les instances des pages
        for F in (MenuPage, GamePage, ScoreboardPage):
            frame = F(container, self)
            self.frames[F] = frame
            frame.grid(row=0, column=0, sticky="nsew")

        # 4. MAINTENANT, on peut afficher la première page
        self.show_frame(MenuPage) 

    def show_frame(self, cont):
        """Affiche un écran (frame) spécifique."""
        frame = self.frames[cont]
        self.current_frame = frame # Mémoriser la page active
        frame.tkraise()

    def get_page(self, page_class):
        """Permet d'accéder à une page depuis une autre page."""
        return self.frames[page_class]
    
    def start_game_with_theme(self, theme):
        """Lance le jeu en passant le thème choisi à la GamePage."""
        game_page = self.get_page(GamePage)
        game_page.demarrer_partie(theme) # On passe le thème à la fonction de démarrage
        self.show_frame(GamePage)

# --- On définit chaque écran comme une classe séparée ---

class MenuPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, bg=COULEUR_FOND)
        self.controller = controller
        
        label = tk.Label(self, text="Track Quiz", font=("Helvetica", 32, "bold"), 
                 bg=COULEUR_FOND, fg=COULEUR_TEXTE)
        label.pack(pady=(80, 40))   

        # --- NOUVEAU : Menu déroulant pour le choix du thème ---
        theme_label = tk.Label(self, text="Choisir un thème :", bg=COULEUR_FOND, fg=COULEUR_TEXTE, font=("Helvetica", 14))
        theme_label.pack()

        # On charge tous les thèmes uniques depuis le fichier CSV
        tous_les_themes = set()
        try:
            with open(FICHIER_QUESTIONS, 'r', encoding='utf-8-sig') as f:
                reader = csv.DictReader(f, delimiter=';')
                for row in reader:
                    if row.get('themes'):
                        themes_question = row['themes'].split('|')
                        tous_les_themes.update(themes_question)
        except FileNotFoundError:
            pass # Géré plus tard au lancement du jeu

        # On crée la liste pour le menu déroulant
        # On trie les thèmes et on ajoute "Tous les thèmes" au début
        options_themes = ["Tous les thèmes"] + sorted(list(tous_les_themes))
        
        self.theme_choisi = tk.StringVar(self)
        self.theme_choisi.set(options_themes[0]) # Valeur par défaut

        theme_menu = tk.OptionMenu(self, self.theme_choisi, *options_themes)
        theme_menu.config(font=("Helvetica", 12), bg=COULEUR_BOUTON, fg=COULEUR_TEXTE, activebackground=COULEUR_BOUTON_SURVOL, bd=0, highlightthickness=0)
        theme_menu["menu"].config(bg=COULEUR_BOUTON, fg=COULEUR_TEXTE, bd=0)
        theme_menu.pack(pady=10)

        # --- Boutons du menu ---
        button_style = {
            "font": ("Helvetica", 18), "bg": COULEUR_BOUTON, "fg": COULEUR_TEXTE,
            "activebackground": COULEUR_BOUTON_SURVOL, "activeforeground": COULEUR_TEXTE,
            "bd": 0, "highlightthickness": 0, "pady": 10, "padx": 20, "width": 15
        }

        play_button = tk.Button(self, text="Jouer", **button_style,
                                command=lambda: self.controller.start_game_with_theme(self.theme_choisi.get()))
        play_button.pack(pady=20)

        score_button = tk.Button(self, text="Classement", **button_style,
                                 command=lambda: controller.get_page(ScoreboardPage).update_scores() or controller.show_frame(ScoreboardPage))
        score_button.pack(pady=10)

        quit_button = tk.Button(self, text="Quitter", **button_style, command=self.controller.master.quit)
        quit_button.pack(pady=10)

class GamePage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, bg=COULEUR_FOND)
        self.controller = controller

        # --- Configuration de la grille principale de la page ---
        # On crée 2 rangées : la première (poids 1) prendra tout l'espace, la seconde (poids 0) restera en bas.
        self.grid_rowconfigure(0, weight=1) 
        self.grid_columnconfigure(0, weight=1)

        # --- Création des deux zones principales ---
        self.top_frame = tk.Frame(self, bg=COULEUR_FOND)
        self.top_frame.grid(row=0, column=0, sticky="nsew") # "nsew" pour que la frame remplisse sa cellule

        self.bottom_frame = tk.Frame(self, bg=COULEUR_FOND)
        self.bottom_frame.grid(row=1, column=0, sticky="ew") # "ew" pour qu'elle s'étire horizontalement

        # --- Widgets de la ZONE HAUTE ---
        self.top_frame.grid_columnconfigure(0, weight=1) # Pour centrer les éléments dans la zone haute

        self.stats_text = tk.StringVar()
        self.stats_label = tk.Label(self.top_frame, textvariable=self.stats_text, font=("Helvetica", 16),
                                    bg=COULEUR_FOND, fg=COULEUR_TEXTE)
        self.stats_label.grid(row=0, column=0, pady=20)

        self.question_frame = tk.Frame(self.top_frame, bg=COULEUR_FOND)
        self.question_frame.grid(row=1, column=0, sticky="nsew")
        # On donne plus d'importance à la rangée de l'image (row=1)
        self.question_frame.grid_rowconfigure(0, weight=0) # Rangée du texte
        self.question_frame.grid_rowconfigure(1, weight=1) # Rangée de l'image
        self.question_frame.grid_columnconfigure(0, weight=1)

        # On place le label de texte en ROW 0
        self.question_text_label = tk.Label(self.question_frame, text="", font=("Helvetica", 18, "italic"),
                                            wraplength=750, bg=COULEUR_FOND, fg=COULEUR_TEXTE)
        self.question_text_label.grid(row=0, column=0, padx=10, pady=(10,0)) # Marge en bas nulle

        # On place le label de l'image en ROW 1
        self.image_label = tk.Label(self.question_frame, bg=COULEUR_FOND)
        self.image_label.grid(row=1, column=0, padx=10, pady=10)

        # --- Widgets de la ZONE BASSE ---
        self.bottom_frame.grid_columnconfigure(0, weight=1) # Pour centrer les éléments

        self.entry = tk.Entry(self.bottom_frame, font=("Helvetica", 16), width=40,
                            bg=COULEUR_ENTRY_FOND, fg=COULEUR_TEXTE,
                            insertbackground=COULEUR_TEXTE, bd=0, justify='center')
        self.entry.pack(pady=10, ipady=8)

        button_style = {
            "font": ("Helvetica", 16), "bg": COULEUR_BOUTON, "fg": COULEUR_TEXTE,
            "activebackground": COULEUR_BOUTON_SURVOL, "activeforeground": COULEUR_TEXTE,
            "bd": 0, "highlightthickness": 0, "pady": 8, "width": 15
        }
        self.submit_button = tk.Button(self.bottom_frame, text="Valider", **button_style, command=self.verifier_reponse)
        self.submit_button.pack(pady=(0, 20))

        # --- Initialisation des variables et de la logique ---
        self.score = 0
        self.vies = VIES_DEPART
        self.questions_disponibles = []
        self.reponse_correcte = ""
        self.theme_actuel = ""
        controller.master.bind('<Return>', lambda event: self.verifier_reponse())


    # --- Méthodes de la logique du jeu ---

    def demarrer_partie(self, theme_choisi="Tous les thèmes"): 
        self.theme_actuel = theme_choisi
        self.score = 0
        self.vies = VIES_DEPART
        self.submit_button.config(state=tk.NORMAL)
        
        toutes_les_questions = []
        try:
            with open(FICHIER_QUESTIONS, 'r', encoding='utf-8-sig') as f:
                reader = csv.DictReader(f, delimiter=';')
                for row in reader:
                    if row.get('contenu') and row.get('reponse'):
                        toutes_les_questions.append(row)
        except FileNotFoundError:
            messagebox.showerror("Erreur", f"Fichier de questions '{FICHIER_QUESTIONS}' introuvable !")
            self.controller.show_frame(MenuPage) # Retour au menu en cas d'erreur
            return

            # --- Filtrage des questions ---
        if theme_choisi == "Tous les thèmes":
            self.questions_disponibles = toutes_les_questions.copy()
        else:
            self.questions_disponibles = []
            for question in toutes_les_questions:
                themes_de_la_question = question.get('themes', '').split('|')
                if theme_choisi in themes_de_la_question:
                    self.questions_disponibles.append(question)
        
        # Si aucun question ne correspond au thème, on affiche un message et on retourne au menu
        if not self.questions_disponibles:
            messagebox.showinfo("Aucune question", f"Il n'y a pas de question pour le thème '{theme_choisi}' pour le moment.")
            self.controller.show_frame(MenuPage)
            return
            
        random.shuffle(self.questions_disponibles)
        self.prochaine_question()

    # Dans la classe GamePage

    def prochaine_question(self):
        if not self.questions_disponibles:
            self.game_over(gagne=True)
            return

        self.entry.delete(0, tk.END)
        self.stats_text.set(f"Score : {self.score} | Vies : {self.vies}")

        # Nettoyage systématique
        self.question_text_label.config(text="")
        self.image_label.config(image='')
        
        question_actuelle = self.questions_disponibles.pop()
        self.reponse_correcte = question_actuelle['reponse']
        
        question_type = question_actuelle['type']
        question_contenu = question_actuelle['contenu']

        # --- NOUVELLE LOGIQUE D'AFFICHAGE ---
        if question_type == 'texte':
            # Pour une question texte, on affiche le contenu dans le label de texte
            self.question_text_label.config(font=("Helvetica", 24, "bold")) # On met une grosse police
            self.question_text_label.config(text=question_contenu)
        
        elif question_type == 'image':
            # Pour une question image, on affiche l'intitulé ET l'image
            intitule = question_actuelle.get('intitule', '') # Récupère l'intitulé, ou "" si vide
            self.question_text_label.config(font=("Helvetica", 18, "italic")) # Police plus petite pour l'intitulé
            self.question_text_label.config(text=intitule)
            
            chemin_image = os.path.join(DOSSIER_IMAGES, question_contenu)
            try:
                img_pil = Image.open(chemin_image)
                img_pil.thumbnail(TAILLE_MAX_IMAGE, Image.Resampling.LANCZOS)
                self.photo_image = ImageTk.PhotoImage(img_pil)
                self.image_label.config(image=self.photo_image)
            except Exception as e:
                print(f"Erreur image : {e}")
                self.prochaine_question() # On saute la question en cas d'erreur
                return

    def verifier_reponse(self):
        if self.controller.current_frame is not self:
            return

        reponse_utilisateur = self.entry.get()
        if not reponse_utilisateur: return

        # --- NOUVELLE LOGIQUE DE VÉRIFICATION ---

        # 1. On nettoie la réponse de l'utilisateur une bonne fois pour toutes.
        reponse_utilisateur_nettoyee = reponse_utilisateur.lower().replace(" ", "")

        # 2. On récupère la chaîne de réponses correctes (ex: "Victor Hugo|hugo")
        #    et on la transforme en une liste (ex: ["Victor Hugo", "hugo"])
        reponses_possibles = self.reponse_correcte.split('|')
        
        # 3. On nettoie CHAQUE réponse possible dans la liste.
        #    C'est ce qu'on appelle une "list comprehension", une façon très pythonique de le faire.
        reponses_correctes_nettoyees = [r.lower().replace(" ", "") for r in reponses_possibles]

        # 4. On vérifie si la réponse de l'utilisateur est DANS la liste des bonnes réponses.
        if reponse_utilisateur_nettoyee in reponses_correctes_nettoyees:
            self.score += 1
            # On peut remettre un petit feedback visuel rapide si on veut
            # self.entry.config(bg="green") 
        else:
            self.vies -= 1
            # On affiche la première réponse de la liste comme étant la "principale"
            reponse_principale = reponses_possibles[0]
            messagebox.showwarning("Dommage...", f"Réponse non acceptée !\nUne bonne réponse était : {reponse_principale.title()}")
        
        # Le reste de la logique pour passer à la suite ou game over
        if self.vies > 0:
            self.prochaine_question()
        else:
            self.game_over(gagne=False)

    def game_over(self, gagne=False):
        """Gère la fin de la partie et l'enregistrement du score dans le bon thème."""
        scores_par_theme = charger_scores()
        
        if self.score > 0:
            nom_joueur = simpledialog.askstring("Fin de la partie", "Entrez votre nom pour le classement :", parent=self)
            if nom_joueur:
                # Récupère la liste des scores pour le thème actuel, ou une liste vide si le thème est nouveau
                classement_du_theme = scores_par_theme.get(self.theme_actuel, [])
                
                # Ajoute le nouveau score
                classement_du_theme.append({'nom': nom_joueur, 'score': self.score})
                
                # Trie la liste pour ce thème
                classement_du_theme.sort(key=lambda x: x['score'], reverse=True)
                
                # Met à jour le dictionnaire principal avec la liste triée et limitée
                scores_par_theme[self.theme_actuel] = classement_du_theme[:10]
                
                sauvegarder_scores(scores_par_theme)

        # On prépare la page de classement pour afficher le thème qu'on vient de jouer
        scoreboard_page = self.controller.get_page(ScoreboardPage)
        scoreboard_page.update_scores(self.theme_actuel) # On lui passe le thème
        self.controller.show_frame(ScoreboardPage)

class ScoreboardPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, bg=COULEUR_FOND)
        self.controller = controller

        label = tk.Label(self, text="Meilleurs Scores", font=("Helvetica", 24, "bold"),
                         bg=COULEUR_FOND, fg=COULEUR_TEXTE)
        label.pack(pady=20)

        # --- Menu déroulant pour le classement ---
        tous_les_themes = set()
        scores = charger_scores()
        tous_les_themes.update(scores.keys())
        
        options_themes = sorted(list(tous_les_themes))
        if not options_themes:
            options_themes = ["-"]

        self.theme_choisi_classement = tk.StringVar(self)
        self.theme_choisi_classement.set(options_themes[0])

        theme_menu = tk.OptionMenu(self, self.theme_choisi_classement, *options_themes, 
                           command=lambda theme: self.update_scores(theme))
        theme_menu.config(font=("Helvetica", 12), bg=COULEUR_BOUTON, fg=COULEUR_TEXTE, 
                          activebackground=COULEUR_BOUTON_SURVOL, bd=0, highlightthickness=0)
        theme_menu["menu"].config(bg=COULEUR_BOUTON, fg=COULEUR_TEXTE, bd=0)
        theme_menu.pack(pady=10)

        # --- Zone d'affichage des scores ---
        self.score_text = tk.Text(self, font=("Courier", 14), width=40, height=12,
                                  bg=COULEUR_ENTRY_FOND, fg=COULEUR_TEXTE, 
                                  bd=0, highlightthickness=0)
        self.score_text.pack(pady=20)
        self.score_text.config(state=tk.DISABLED)

        # --- Bouton Retour ---
        button_style = {
            "font": ("Helvetica", 16), "bg": COULEUR_BOUTON, "fg": COULEUR_TEXTE,
            "activebackground": COULEUR_BOUTON_SURVOL, "activeforeground": COULEUR_TEXTE,
            "bd": 0, "highlightthickness": 0, "pady": 8, "padx": 18
        }
        back_button = tk.Button(self, text="Retour au Menu", **button_style,
                                command=lambda: controller.show_frame(MenuPage))
        back_button.pack(pady=20)

    def update_scores(self, theme=None):
        """Met à jour l'affichage des scores pour un thème donné."""
        if theme is None:
            theme = self.theme_choisi_classement.get()
        else:
            # On vérifie que le thème existe dans les options avant de le définir
            if theme in self.theme_choisi_classement.get():
                self.theme_choisi_classement.set(theme)

        self.score_text.config(state=tk.NORMAL)
        self.score_text.delete('1.0', tk.END)
        
        scores_par_theme = charger_scores()
        classement_du_theme = scores_par_theme.get(theme, [])
        
        if not classement_du_theme:
            self.score_text.insert(tk.END, f"Aucun score pour le thème\n'{theme}'")
        else:
            for i, entry in enumerate(classement_du_theme):
                self.score_text.insert(tk.END, f"{i+1: >2}. {entry['nom']: <20} {entry['score']: >3}\n")
        
        self.score_text.config(state=tk.DISABLED)

if __name__ == "__main__":
    root = tk.Tk()
    my_app = QuizApp(root)
    root.mainloop()